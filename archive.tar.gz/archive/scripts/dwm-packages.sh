#!/bin/sh

# Displays number of upgradeable packages
# checkupdates is found in pacman-contrib.

checkupdates | wc -l | sed "s/^/ /;s/^ 0$//g"
