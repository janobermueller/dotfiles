#!/bin/sh

# Displays the date and time

date "+%a %-d. %b %R"
