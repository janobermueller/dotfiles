#!/bin/sh

# Prints the used memory in percent

free -m | sed -n '2p' | awk '{printf(" %.f%\n"), ( $3 / $2 ) * 100}'
