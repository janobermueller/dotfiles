#!/bin/sh

# Displays the battery charge and charge status

for battery in /sys/class/power_supply/BAT?
do
	capacity=$(cat "$battery"/capacity 2>/dev/null) || break
	status=$(sed "s/[Dd]ischarging//;s/[Nn]ot charging//;s/[Cc]harging//;s/[Uu]nknown//;s/[Ff]ull//" "$battery"/status)

	printf "%s%s%s%% " "$status " "$capacity"
done | sed 's/ *$//'
