#!/bin/sh

# Continuously updates the dwm status bar

print() {
	"$SCRIPTS/dwm-$1.sh"
}

while :; do
	xsetroot -name "| $(print packages) | $(print memory) | $(print network) | $(print battery) | $(print date) "
	sleep 1m
done
